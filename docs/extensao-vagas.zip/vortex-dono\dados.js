// Validação e montagem do docs/dados.json. Uma leitura incompleta nunca substitui os dados publicados.
const airportCode = /^[A-Z0-9]{3,5}$/;
const tailCode = /^[A-Z0-9-]{2,12}$/;
const pilotName = /^[\w.-]{1,40}$/;
const isoDay = /^\d{4}-\d{2}-\d{2}$/;
const isRecord = value => value !== null && typeof value === "object" && !Array.isArray(value);
const label = (value, limit) => typeof value === "string" && value.trim() && value.length <= limit;
const validCode = code => typeof code === "string" && airportCode.test(code);
const count = (value, max) => Number.isInteger(value) && value >= 0 && value <= max;
const amount = (value, min, max) => typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;

// O PilOps mostra só os 10 últimos voos; guardamos tudo o que já foi lido, sem repetir.
const flightKey = f => [f.date, f.pilot, f.prefix, f.origin, f.destination, f.minutes, f.revenue].join("|");
const operationalKey = f => [f.date, f.pilot, f.prefix, f.origin, f.destination, f.minutes, f.nm].join("|");
const maxStoredFlights = 20000;

function cleanPilots(pilots) {
  if (!Array.isArray(pilots) || pilots.length < 1 || pilots.length > 500) return null;
  if (!pilots.every(p => isRecord(p) && pilotName.test(p.name || "") && (p.role === null || label(p.role, 20)) &&
      (p.level === null || count(p.level, 1000)) && count(p.totalMinutes, 10_000_000) && count(p.companyMinutes, 10_000_000) &&
      (p.joined === null || isoDay.test(p.joined || ""))) || new Set(pilots.map(p => p.name)).size !== pilots.length) return null;
  return pilots.map(({ name, role, level, totalMinutes, companyMinutes, joined }) =>
    ({ name, role, level, totalMinutes, companyMinutes, joined }));
}

function cleanFlights(flights) {
  if (!Array.isArray(flights) || flights.length > 200) return null;
  if (!flights.every(f => isRecord(f) && pilotName.test(f.pilot || "") && tailCode.test(f.prefix || "") && label(f.model, 120) &&
      validCode(f.origin) && validCode(f.destination) && isoDay.test(f.date || "") && count(f.minutes, 3000) &&
      amount(f.nm, 0, 20000) && [f.fuel, f.payload].every(v => v === undefined || v === null || amount(v, 0, 2_000_000)) &&
      amount(f.revenue, -1e10, 1e10))) return null;
  return flights.map(withFuel);
}

// As "lbs" do histórico do PilOps são o combustível utilizado. Até a versão 1.5.0 a extensão chamava esse
// número de "payload"; voos antigos são convertidos aqui.
export function withFuel({ pilot, prefix, model, origin, destination, date, minutes, nm, fuel, payload, revenue }) {
  const used = fuel ?? payload ?? null;
  return { pilot, prefix, model, origin, destination, date, minutes, nm, fuel: used, revenue };
}

// Voos que a extensão do dono publicou no dados.json entre duas coletas do Rafael. Entram no histórico privado
// na forma pública (sem receita nem combustível, só "paid"). Se o Rafael ainda vir o voo na lista do PilOps,
// buildSnapshot troca essa versão pela completa (mesma chave operacional).
export function withPublished(previous, published) {
  if (!isRecord(published) || !Array.isArray(published.flights)) return previous;
  const base = isRecord(previous) ? previous : published;
  const known = new Set((base.flights || []).map(operationalKey));
  const extra = published.flights.filter(f => isRecord(f) && pilotName.test(f.pilot || "") && tailCode.test(f.prefix || "") &&
    label(f.model, 120) && validCode(f.origin) && validCode(f.destination) && isoDay.test(f.date || "") &&
    count(f.minutes, 3000) && amount(f.nm, 0, 20000) && !known.has(operationalKey(f)))
    .map(({ pilot, prefix, model, origin, destination, date, minutes, nm, paid }) =>
      ({ pilot, prefix, model, origin, destination, date, minutes, nm, paid: paid === true }));
  if (!extra.length) return base;
  return { ...base, flights: [...(base.flights || []), ...extra], flightsSince: base.flightsSince || published.flightsSince || null };
}

// Rotas incompletas (segunda revisão do Codex, 28/11/2026; substitui a regra da "metade" da primeira revisão, que
// deixava passar 20 de 39 rotas): uma lista sem o total da página (routesConfirmed diferente de true) não pode
// apagar mais que duas rotas publicadas, e nenhuma lista vazia substitui a malha. Nesses casos ficam as rotas
// publicadas e o resto da leitura (frota, pilotos, voos) segue. Lista confirmada pelo total vale sempre, mesmo com
// muitas rotas removidas. Devolve o motivo ou null.
const routeKey = r => [r.code, r.origin, r.destination].join("|");
export function routesKept(input, previous) {
  if (!Array.isArray(previous?.routes) || !previous.routes.length) return null;
  if (Array.isArray(input?.routes) && !input.routes.length) return "a leitura não trouxe nenhuma rota ativa; ficaram as publicadas";
  if (input?.routesConfirmed === true) return null;
  const read = new Set((Array.isArray(input?.routes) ? input.routes : []).map(routeKey));
  const missing = previous.routes.filter(r => !read.has(routeKey(r))).length;
  return missing > 2 ? "a lista lida (sem o total da página) não tem " + missing + " das " + previous.routes.length +
    " rotas publicadas; ficaram as publicadas" : null;
}

// input: leitura da extensão; previous: dados.json publicado (ou null).
export function buildSnapshot(input, previous, now = new Date()) {
  const data = input;
  if (!isRecord(data) || !Array.isArray(data.fleet) || data.fleet.length < 1 || data.fleet.length > 250 ||
      !Array.isArray(data.routes) || data.routes.length > 1000 ||
      !Array.isArray(data.hubs) || data.hubs.length < 1 || data.hubs.length > 20 ||
      !Number.isInteger(data.reportedFleet) || data.reportedFleet < data.fleet.length || data.reportedFleet > 250) return null;
  const { fleet, routes, hubs } = data;
  if (!fleet.every(p => isRecord(p) && typeof p.prefix === "string" && tailCode.test(p.prefix) &&
    label(p.model, 120) && validCode(p.airport) && (p.base === null || validCode(p.base)) && label(p.status, 180)) ||
    new Set(fleet.map(p => p.prefix)).size !== fleet.length ||
    !routes.every(r => isRecord(r) && validCode(r.origin) && validCode(r.destination) &&
      r.origin !== r.destination && typeof r.code === "string" && /^VTX[0-9]{1,12}$/.test(r.code)) ||
    !hubs.every(validCode) || new Set(hubs).size !== hubs.length) return null;
  const kept = routesKept(data, previous);

  // Pilotos e voos são opcionais: se a leitura falhar, mantemos o que já estava publicado.
  const pilots = data.pilots === undefined || data.pilots === null ? null : cleanPilots(data.pilots);
  const newFlights = data.flights === undefined || data.flights === null ? null : cleanFlights(data.flights);
  const merged = new Map((previous?.flights || []).map(f => [flightKey(f), Number.isFinite(f.revenue) ? withFuel(f) : f]));
  let added = 0;
  for (const f of newFlights || []) {
    if (!merged.has(flightKey(f))) {
      // Sem o arquivo privado, recupera o histórico operacional público sem duplicar os voos relidos.
      const recovered = [...merged].find(([, old]) => !Number.isFinite(old.revenue) && operationalKey(old) === operationalKey(f));
      if (recovered) merged.delete(recovered[0]); else added++;
      merged.set(flightKey(f), f);
    }
  }
  const flights = [...merged.values()].sort((a, b) => b.date.localeCompare(a.date)).slice(0, maxStoredFlights);
  const today = now.toISOString().slice(0, 10);

  return {
    snapshot: {
      capturedAt: now.toISOString(),
      reportedFleet: data.reportedFleet,
      fleet: fleet.map(({ prefix, model, airport, base, status }) => ({ prefix, model, airport, base, status })),
      routes: (kept ? previous.routes : routes).map(({ origin, destination, code }) => ({ origin, destination, code })),
      hubs,
      pilots: pilots || previous?.pilots || [],
      pilotsCapturedAt: pilots ? now.toISOString() : previous?.pilotsCapturedAt || null,
      flights,
      // Primeiro dia em que o histórico de voos foi lido: o ranking por voos vale a partir daqui.
      flightsSince: previous?.flightsSince || (newFlights ? (flights.at(-1)?.date || today) : null),
    },
    report: { pilotsRead: Boolean(pilots), pilotsInvalid: data.pilots != null && !pilots,
      flightsRead: Boolean(newFlights), flightsInvalid: data.flights != null && !newFlights, flightsAdded: added,
      routesKept: kept },
  };
}
